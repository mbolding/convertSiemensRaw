/// \file MeasRead.cpp
/// \brief Converts meas.out files to matlab files (C-module for Matlab inclusion).
///
/// \author Ralf Loeffler
/// \version 1.0
/// \date    2005
/// This file is a basic read routine and meant to serve as a template for own extensions.
/// It is adviced to always recompile with the actual version of the numaris header files.
/// This file was created as a service to the IDEA community.
/// This file just dumps the needed MDH information and the raw data into a long vector
/// sorting for dimensions can be easily done in matlab with the given information 
/// \warning Make sure that the h files are found.\n
/// best way is by using the matlabit batch file for compilation\n
/// Execute mex -setup and set compiler to VC++ 6.0
/// Also make sure that MdhProxy.lib is linked to the executable
/// \warning This version is compatible with Numaris4 VA25 and VB11.
/// Any accomodations for other Sw Versions should only affect defines and getxxxvalue functions
/// of MLMDH. The used matlab version is V. 7.0.4
/// \warning This Program is only tested on a PC, I don't know whether the Numaris includes will work on linux
/// (there is a lot of low level byte aligning etc. going on).

/// Std. C-includes
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<memory.h>
#include <iostream.h>

/// matlab mex includes
#include "mex.h"
#include "matrix.h"

/// Numaris includes
/// A standard IDEA installation is assumed
#include "memory.h" // for MrBitField.h
#include "v:\n4\pkg\MrServers\MrMeasSrv\SeqIF\MDH\mdhproxy.h"

#ifndef max
/// defining the max macro
#define max(a, b)  (((a) > (b)) ? (a) : (b))
#endif

/// as of now, we do not have ADC's witth more than 4k points, so we should be save
#define MAX_NO_DATA_POINTS (8192)
/// 32 is the number of dummy bytes in front of the first mdh
#define DUMMY_SIZE (32)

/// \brief object definition for MatlabMDH \n
///
/// Contains methods for easy bookkeeping of the MDH fields to be exported to MatLab
/// If you want to add additional MDH information to Matlab, this is the only place to touch
/// (except you want to introduce a new data type)
/// The only reason this object exists is that we only have to change things in this one place
/// if we add new MDH flags.
class MatlabMDH{
public:
	/// Constructor: only thing it does is to define the number of elements in the structure
	MatlabMDH(){
	NoOfNumericElements=16; // update when numeric elements are added 
	NoOfStringElements=1; 	// update when string elements are added
	NoOfLogicalElements=2; 	// update when logical elements are added
	};
	
	/// \name Functions needed for Numeric Fields 
	//@{ 
	
	/// \brief Function used to pull the Strings for the Matlab struct
	///
	/// \warning Always make changes to this function in tandem with the correspoinding \link MatlabMDH::getNumericValue()  getNumericValue \endlink  function
	char* getNumericNameString(int index){
		switch (index){
			case  0: return "NoOfColumns";
			case  1: return "CurChannel";
			case  2: return "CurLine";
			case  3: return "CurAcqu";
			case  4: return "CurSlice";
			case  5: return "CurPart";
			case  6: return "CurEcho";
			case  7: return "CurPhase";
			case  8: return "CurRep";
			case  9: return "CurSet";
			case 10: return "CurSeg";
			case 11: return "CurIda";
			case 12: return "CurIdb";
			case 13: return "CurIdc";
			case 14: return "CurIdd";
			case 15: return "CurIde";				
			default: mexErrMsgTxt("Error: Index for name string out of bounds.");;
		}
	}

	/// Function used to get the numeric values out of the MDH and into the Matlab MDH
	double getNumericValue(sMDH* MDH, int index){
		MdhProxy theMDH(MDH);
		switch (index){
			case  0: return (theMDH.getNoOfColumns()); // "NoOfColumns";
			case  1: return (MDH->ulChannelId); // this is bad but necessary since no get method exists... "CurChannel";
			case  2: return (theMDH.getClin()); // "CurLine";
			case  3: return (theMDH.getCacq()); // "CurAcqu";
			case  4: return (theMDH.getCslc()); // "CurSlice";
			case  5: return (theMDH.getCpar()); // "CurPart";
			case  6: return (theMDH.getCeco()); // "CurEcho";
			case  7: return (theMDH.getCphs()); // "CurPhase";
			case  8: return (theMDH.getCrep()); // "CurRep";
			case  9: return (theMDH.getCset()); // "CurSet";
			case 10: return (theMDH.getCseg()); // "CurSeg";
			case 11: return (theMDH.getCida()); // "CurIda";
			case 12: return (theMDH.getCidb()); // "CurIdb";
			case 13: return (theMDH.getCidc()); // "CurIdc";
			case 14: return (theMDH.getCidd()); // "CurIdd";
			case 15: return (theMDH.getCide()); // "CurIde";			
			//  more info can be found in the mdhproxy.h file...		
			default: mexErrMsgTxt("Error: Index for numeric value out of bounds.");;
		}
	}
	
	/// get function to access private member containing the number of numeric Elements
	int getNumberOfNumericElements(){
		return NoOfNumericElements;
	}
	
	/// \brief returns the start index of the Numeric element field 
	///
	/// (no index in the MLMDH object should exist
	/// twice, this makes it easier to deal with the matlab structure)
	int getStartIndexNumericElements(){
		return 0;
	}
	
	/// returns the final index of the Numeric element field
	int getEndIndexNumericElements(){
		return NoOfNumericElements - 1;
	}
	//@}
	
	/// \name Functions needed for String Fields 
	//@{ 
	
	/// \brief Function used to pull the Strings for the string part of  Matlab struct
	///
	/// \warning Always make changes to this function in tandem with the correspoinding \link MatlabMDH::getStringValue()  getStringValue \endlink function
	char* getStringNameString(int index){
		switch (index - getStartIndexStringElements()){
			case  0: return "AcqEnd";
			//case  1: return "CurChannel";
			default: mexErrMsgTxt("Error: Index for name string out of bounds.");;
		}
	}

	/// Function used to get the string values out of the MDH and into the Matlab MDH
	char* getStringValue(sMDH* MDH, int index){
		MdhProxy theMDH(MDH);
		switch (index - getStartIndexStringElements()){
			case  0: return (theMDH.getEvalInfoMask() & MDH_ACQEND)?"MDH_ACQEND":" ";
			//case  1: return (MDH->ulChannelId); // this is bad but necessary since no get method exists... "CurChannel";
			//  more info can be found in the mdhproxy.h file...		
			default: mexErrMsgTxt("Error: Index for String value out of bounds.");;
		}
	}
	
	/// get function to access private member containing the number of string Elements	
	int getNumberOfStringElements(){
		return NoOfStringElements;
	}
	
	/// returns the start index of the string element field
	int getStartIndexStringElements(){
		return NoOfNumericElements ;
	}
	
	/// returns the final index of the string element field
	int getEndIndexStringElements(){
		return NoOfNumericElements + NoOfStringElements - 1;
	}
	//@}
	
	/// \name Functions needed for Boolean (Logical) Fields 
	//@{
	
	/// \brief Function used to pull the strings for the logical part of Matlab struct
	///
	/// \warning Always make changes to this function in tandem with the correspoinding \link MatlabMDH::getLogicalValue()  getLogicalValue \endlink   function
	char* getLogicalNameString(int index){
		switch (index - getStartIndexLogicalElements()){
			case  0: return "MDH_SWAPPED";
			case  1: return "MDH_SIGNREV";
			default: mexErrMsgTxt("Error: Index for name string out of bounds.");;
		}
	}

	/// Function used to get logical values out of the MDH and into the Matlab MDH
	bool getLogicalValue(sMDH* MDH, int index){
		MdhProxy theMDH(MDH);
		switch (index - getStartIndexLogicalElements()){
			case  0: return (theMDH.getEvalInfoMask() & MDH_SWAPPED);
			case  1: return (theMDH.getEvalInfoMask() & MDH_SIGNREV);
			default: mexErrMsgTxt("Error: Index for logical value out of bounds.");;
		}
	}

	/// get function to access private member containing the number of string Elements		
	int getNumberOfLogicalElements(){
		return NoOfLogicalElements;
	}
	
	/// returns the start index of the string element field
	int getStartIndexLogicalElements(){
		return NoOfNumericElements + NoOfStringElements;
	}
	
	/// returns the final index of the string element field	
	int getEndIndexLogicalElements(){
		return NoOfNumericElements + NoOfStringElements + NoOfLogicalElements - 1;
	}
	//@}
	
	/// This function yields to total number of elements of all (numeric, string and logical)  fields
	int getNumberOfTotalElements(){
		return NoOfNumericElements + NoOfStringElements + NoOfLogicalElements;
	}

private:

	/// \warning update initialization in constructor if numeric elements added
	/// 
	/// \brief private data member containing the number of numerical elements to be written into the Matlab MDH
	int NoOfNumericElements; 
	
	/// \warning update initialization in constructor if string elements added
	/// 
	/// \brief private data member containing the number of string elements to be written into the Matlab MDH
	///
	int NoOfStringElements; 
	
	/// \warning update initialization in constructor if bool elements added
	/// 
	/// \brief private data member containing the number of logical (boolean) elements to be written into the Matlab MDH
	///
	int NoOfLogicalElements; 


};


// function prototype, put into header file at a later point in time
///
/// function prototype for determine size, this routine is used to determine the raw data size,
/// i.e. the number of MDH's and the number of samples. 
bool DetermineSize(
				char    *dataFileName,		///< input:  char string containing the data file name
				long    *MdhCount,			///< output: Number of ADC structures
				long    *SamplesPerADC		///< output: (Maximum) number of sample points per ADC
				);

///
/// function prototype for MeasRead, the actual read routine. The actual transformation in matlab format takes place in this routine
bool MeasRead(
				char    	*name,				///< input:  char string containing the data file name
				const char **fnames,			///< output: field names for array
				long 	  	 SamplesPerADC,		///< length of the Data array
				mxArray  	*MdhArray,			///< output: MDH Structure
				double  	*DataArrayReal,		///< output: actual data structure
				double  	*DataArrayImag		///< output: actual data structure
				);


/// \brief Interface function for matlab
///
/// The function interface is determined by matlab
void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{
	
	/// This is the matlab function call:
	///
	/// the c function interface should be called in the following way
	/// \n
	///  <b>[MDH (structure), \n
	///   Data (2D-array)] \n
	///  = MeasRead \n
	///  (filename (string) </b>\n
	/// e.g.:\n
	/// <tt>[MDH, Data] = MeasRead('meas.out'); </tt>\n
	/// 
	/// 	
	/// 	
	// all the mx and mex functions can be found in the matlab help 
	// under external interface reference

	// Check for proper number of arguments. 
	if (nrhs > 1) {
		mexErrMsgTxt("Too many input arguments");
	} 
	if (nlhs > 2) {
		mexErrMsgTxt("Too many output arguments");
	}
	if (nlhs < 2) {
		mexErrMsgTxt("not enough output arguments");
	};
	
	char *name; 	// Filename
    int   buflen; 	//  help variable
	MatlabMDH MLMdh; // create an instance of the Matlab MDH object
	// get the length of the input string 
    buflen = (mxGetM(prhs[0]) * mxGetN(prhs[0])) + 1;
    // allocate memory for name strings 
    name = (char *) mxCalloc(max(buflen,255), sizeof(char));
 
	// assign pointer to the input field
	// and check that the data is correct  
	// start with the 3D array
	if (nrhs < 1) {
		mexPrintf("\nNo name specified, will use meas.out.\n");
		sscanf("meas.out","%s",name);
	} else {
		if (!(mxIsChar(prhs[0]))) {
			mexErrMsgTxt("Input data must be a string");
		}
		// copy the string data from prhs[0] into a C string name.
		// If the string array contains several rows, they are copied,
		// one column at a time, into one long string array, which really makes no sense
		int status = mxGetString(prhs[0], name, buflen);
		if(status != 0){ 
			mexErrMsgTxt("Error: Not enough space. Name was truncated.");
		}
	}
	long MdhCount = 0; 		// Number of MDH's to convert
	long SamplesPerADC = 0; // max. number of (complex) Samples per ADC
	// now we parse the input file for the first time.
	// we unfortunately have to parse twice the meas.out file since we don't know the size....
	bool myreturn = DetermineSize(name, &MdhCount, &SamplesPerADC);	
	if (myreturn == false){
		mexErrMsgTxt("Function DetermineSize returned with an error\n");
	}
	mexPrintf("\nI counted %d MDH's with a maximum length of %d samples\n", MdhCount, SamplesPerADC);
	// create output fields
    const char **fnames;       							// pointers to matlab MDH field names 
	int nfields = MLMdh.getNumberOfTotalElements();		// number of fields in matlab MDH 
    // allocate memory  for storing pointers
    fnames = (const char **) mxCalloc(nfields, sizeof(*fnames));
	//mexPrintf("\nallocating field with length: %d MDH's with a maximum length of %d samples\n", MdhCount, SamplesPerADC);
	// initialize the field names
	for(int name_index  = MLMdh.getStartIndexNumericElements(); 
		    name_index <= MLMdh.getEndIndexNumericElements();name_index++){
		fnames[name_index] = MLMdh.getNumericNameString(name_index);
	}
	for(name_index = MLMdh.getStartIndexStringElements(); 
			name_index <= MLMdh.getEndIndexStringElements();name_index++){
		fnames[name_index] = MLMdh.getStringNameString(name_index);
	}
	for(name_index = MLMdh.getStartIndexLogicalElements(); 
			name_index <= MLMdh.getEndIndexLogicalElements();name_index++){
		fnames[name_index] = MLMdh.getLogicalNameString(name_index);
	}
	// create structures for returning the data
	// structure containing the MDH's
	plhs[0]	= mxCreateStructMatrix(MdhCount, 1,  nfields,  fnames); 
	// vector containing the raw data
	plhs[1]	= mxCreateDoubleMatrix(SamplesPerADC, MdhCount, mxCOMPLEX);

	double  *DataArrayReal	= (double *)  mxGetPr(plhs[1]); // pointer to the Real part of the (matlab) data Array
	double  *DataArrayImag	= (double *)  mxGetPi(plhs[1]); // pointer to the Real part of the (matlab) data Array
	// no pointer gets assigned to the MDH structure, since this is just a pointer field, which we have to fill with the pointers to the actual data.
	
	// maybe it would have been cleaner to get a pointer to the data field and figure out length, real and imag start part within the function
	// Call to the read and fill the matlab structure function
	myreturn = MeasRead(name, fnames, SamplesPerADC, plhs[0], DataArrayReal, DataArrayImag);	
	if (myreturn == false){
		mexErrMsgTxt("Function MeasRead returned with an error\n");
	}

}

/// \brief DetermineSize determines the number of MDH's and the number of samples
bool DetermineSize(
				char    *dataFileName,		
				long    *MdhCount,			
				long    *SamplesPerADC){	
	// variables
	sMDH MDH;				// MDH structure, data from file is read into it		
	MdhProxy theMDH(& MDH);	// MDH Proxy object used to allow clean (C++-like) access to the MDH)
	FILE *readptr;			// file pointer for the meas.out file
	float raw_columns[MAX_NO_DATA_POINTS];	// Float array, used to read the raw data into.

	// open file for reading
	readptr=fopen(dataFileName,"rb");
	if (readptr ==NULL)
	{
		mexErrMsgIdAndTxt("MATLAB:InputError"," source file %s not found\n", dataFileName);
		return false;
	}
	
	// read the first data from the file
	// the first 32 characters of the meas file have to be ignored
	// To my knowledge they contain a magic cookie to identify them as meas files (could be used for further checks)
	const int dummy_size = DUMMY_SIZE;
	char dummy[dummy_size];
	int readitems = fread(&dummy,sizeof(char),dummy_size,readptr);
	if (readitems != dummy_size)
	{
		mexErrMsgIdAndTxt("MATLAB:InputError"," could only read %d instead of desired %d dummy characters from source file: %s \n", readitems, dummy_size, dataFileName);
		return false ;
	}
	
	// start reading in the actual data
	long tempcounter=0;		// helper variable
	long datapoints = 0;	// helper variable
	// loop over the raw data 
	// this is done in a do/while loop since we only know whether the MDH is the last one once we have read it
	do
    {
		// read the MDH which precedes the raw data
		readitems = fread(& MDH,sizeof(sMDH),1,readptr);
		if (readitems != 1)
		{
			mexErrMsgIdAndTxt("MATLAB:InputError"," could not read full length of MDH from source file: %s\n", dataFileName);
			return false;
		}
		// factor of 2 is needed for real/imag data,
		datapoints = theMDH.getNoOfColumns()*2;
		*SamplesPerADC = max(datapoints/2,*SamplesPerADC);				
		//mexPrintf("Dataset %d: MDH yields %d data points\n", tempcounter, datapoints);
		// read the actual data (will be discarded, we also could use fskip, I guess?)
		readitems = fread(& raw_columns,sizeof(float),datapoints,readptr);
		if (readitems != datapoints)
		{
			mexErrMsgIdAndTxt("MATLAB:InputError"," could only read %d instead of desired %d data points  from source file: %s \n", readitems, datapoints, dataFileName);
			return false;
		}
	// increment the help counter with each MDH read	
	tempcounter++;
	} while (!(theMDH.getEvalInfoMask() & MDH_ACQEND));
	// remark: we may mot read to the end of the file, if there are more than one coils connected, 
	// but we discard the last ADC anyway, so no harm done...
	// cloese file and fill return variable
	fclose(readptr);
	*MdhCount = tempcounter;
	return true;			
}

/// \brief MeasRead does the transformation
bool MeasRead(	char		*dataFileName,			
				const char **fnames,	
				long 	  	 SamplesPerADC,						
				mxArray		*MdhArray,			
				double	 	*DataArrayReal, 
				double		*DataArrayImag) {
	sMDH MDH;								// MDH structure, data from file is read into it
	MdhProxy theMDH(& MDH);					// MDH Proxy object used to allow clean (C++-like) access to the MDH)
	MatlabMDH MLMdh;						// create an instance of the Matlab MDH object
	float raw_columns[MAX_NO_DATA_POINTS];	// Float array, used to read the raw data into
	FILE *readptr;							// file pointer for the meas.out file
	
	// open file for read access
	readptr=fopen(dataFileName,"rb");
	if (readptr ==NULL)
	{
		mexErrMsgIdAndTxt("MATLAB:InputError"," source file %s not found\n", dataFileName);
		return false;
	}	
	// this needs to be done more intelligent than just copying code...
	// subfunction with filepointer and file name as arguments -> later
	const int dummy_size =DUMMY_SIZE;   // helper variable
	char dummy[dummy_size];				// helper variable
	// read in the lead charaters
	int readitems = fread(&dummy,sizeof(char),dummy_size,readptr);	// helper variable
	if (readitems != dummy_size)
	{
		mexErrMsgIdAndTxt("MATLAB:InputError"," could only read %d instead of desired %d dummy characters from source file: %s \n", readitems, dummy_size, dataFileName);
		return false ;
	}

	long MdhCounter=0;			// helper variable
	long DataSamples = 0;		// helper variable
	long ComplexDataPoints = 0;	// ComplexDataPoints is just half of DataSamples but it is introduced for clarity
	mxArray* FieldPointer;
	// loop over the raw data 
	// this is done in a do/while loop since we only know whether the MDH is the last one once we have read it
	do
    {
		// read in the MDH
		readitems = fread(& MDH,sizeof(sMDH),1,readptr);
		if (readitems != 1){
			mexErrMsgIdAndTxt("MATLAB:InputError"," could not read full length of MDH from source file: %s\n", dataFileName);
			return false;
		}
		// here goes the MDH filling
		ComplexDataPoints = theMDH.getNoOfColumns(); // use variable since needed later
		
		DataSamples = 2 * ComplexDataPoints;
		if(DataSamples > MAX_NO_DATA_POINTS){
			mexErrMsgTxt("Error: data vector longer that 8k (which is weird)\n");
			return false;
		}
		// setting by field number is supposed to be faster, but we do it  by name for clarity
		// note that the matlab struct arrays are  arrays containing only pointers, so one needs to 
		// allocate memory to to hold the actual value first as done with the mxcreate...
		// (all of this matlab create stuff is highly confusing, since in contrast the numeric arrays do 
		// hold the actual elements) 
		for(int name_index = MLMdh.getStartIndexNumericElements(); 
				name_index <= MLMdh.getEndIndexNumericElements();name_index++){
			mxSetField(MdhArray, MdhCounter, MLMdh.getNumericNameString(name_index), 
				mxCreateDoubleScalar(MLMdh.getNumericValue(&MDH, name_index)));
		}
		// for demonstration purposes we also read in some strings. 
		// as mentioned above in a similar way one could add additional functions to MLMDH to read in some logical variables

		for(name_index = MLMdh.getStartIndexStringElements(); 
			name_index <= MLMdh.getEndIndexStringElements();name_index++){
			mxSetField(MdhArray, MdhCounter, MLMdh.getStringNameString(name_index), 
				mxCreateString(MLMdh.getStringValue(&MDH, name_index)));
		}
		// read in some logical elements as well
		for(name_index = MLMdh.getStartIndexLogicalElements(); 
			name_index <= MLMdh.getEndIndexLogicalElements();name_index++){
			mxSetField(MdhArray, MdhCounter, MLMdh.getLogicalNameString(name_index), 
				mxCreateLogicalScalar(MLMdh.getLogicalValue(&MDH, name_index)));
		}

		// here we start reading the raw data
		readitems = fread(& raw_columns,sizeof(float),DataSamples,readptr);
		if (readitems != DataSamples)
		{
			mexErrMsgIdAndTxt("MATLAB:InputError"," could only read %d instead of desired %d data samples  from source file: %s \n", readitems, DataSamples, dataFileName);
			return false;
		}
		// loop over the single data points
		for (int i = 0; i < ComplexDataPoints; i++){
			// Pointer to the start address of the real part of the Data field
			*(DataArrayReal + (MdhCounter * SamplesPerADC) +i) = raw_columns[i*2];
			// Pointer to the start address of the imaginary part of the Data field
			*(DataArrayImag + (MdhCounter * SamplesPerADC) +i) = raw_columns[(i*2)+1];
		}		
	MdhCounter++;
	} while (!(theMDH.getEvalInfoMask() & MDH_ACQEND));
	// remark: we do not read to the end of the file, if there are more than one coils connected, 
	// but the last ADC carries no informatin anyway, so no harm done...	
	fclose(readptr);
	mexPrintf("\nI converted %d MDH's with a maximum length of %d samples\n", MdhCounter, SamplesPerADC);

	return true;
}

