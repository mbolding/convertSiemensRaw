This zip files contains all the files needed to enable one to read in meas.out files into matlab.
Features of the software include:
- utilization of the Numaris header files, therefore compatibility is ensured, 
  future software versions can be accomodated easily.
- Information about the MDH values to be imported are kept in an object. 
  This allows to easily add/remove MDH entries to be imported into matlab, 
  without combing through the whole source code.
- information is imported into matlab using the MDH/matching_data approach,
  this makes the program universal and suited for any kind of data, 
  but of course the sorting has to be done in matlab 
  (where it can be done easily, see example)
- an attempt was made to document the software extensively so that it can be modified easily.

It is very much appreciated that YOU post updates to the software on the IDEA board if you made changes to it 
which are of general interest. As a matter of fact, I think it will be much appreciated if ALL MDH
entries would be reflected in matlab (I just got tired). one can always use the program mdb or check the mdhproxy.x
files for further missing mdh entries.

The zip file contains the following files:
- the actual surce code for the c-program (mesread.cpp)
- a batch file which allows easy compilation of the cpp file (please note that this only is tested with visual c 6.0 (MatLabIt.bat)
- the compiled dll (suitable for VA25 and matlab 7.0.4) (MeasRead.dll)
- an example file which shows how to extract info from the imported data structures (example.m)
- a doxygen configuration file which was used to generate the documentation in the
- doc directory.

Enjoy
Ralf